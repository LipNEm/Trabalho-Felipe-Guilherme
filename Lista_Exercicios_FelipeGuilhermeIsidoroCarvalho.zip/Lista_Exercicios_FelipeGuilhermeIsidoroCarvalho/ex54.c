/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 54
 * Descricao: Le duas strings e compara se sao iguais usando a funcao
 *            strcmp() da biblioteca string.h.
 * Data: 24/09/2026
 */
#include <stdio.h>
#include <string.h>

int main(void) {
    char s1[100], s2[100];
    printf("Digite a primeira string: ");
    scanf("%99s", s1);
    printf("Digite a segunda string: ");
    scanf("%99s", s2);

    if (strcmp(s1, s2) == 0) printf("As strings sao iguais\n");
    else printf("As strings sao diferentes\n");

    return 0;
}
