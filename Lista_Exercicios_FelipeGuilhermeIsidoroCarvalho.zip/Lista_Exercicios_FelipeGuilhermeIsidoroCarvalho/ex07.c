/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 07
 * Descricao: Controla um semaforo com as fases Verde, Amarelo e Vermelho,
 *            repetindo o ciclo indefinidamente.
 * Data: 24/09/2026
 */
#include <stdio.h>
#include <unistd.h>

int main(void) {
    while (1) {
        printf("Sinal VERDE\n");
        sleep(30);
        printf("Sinal AMARELO\n");
        sleep(5);
        printf("Sinal VERMELHO\n");
        sleep(25);
    }
    return 0;
}
