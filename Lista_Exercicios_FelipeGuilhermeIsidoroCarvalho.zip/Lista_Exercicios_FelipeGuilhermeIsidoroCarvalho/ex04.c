/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 04
 * Descricao: Simula o algoritmo de uma fila de banco, chamando cada senha.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int n;
    printf("Quantas pessoas estao na fila? ");
    scanf("%d", &n);

    for (int i = 1; i <= n; i++) {
        printf("Senha %d\n", i);
    }
    return 0;
}
