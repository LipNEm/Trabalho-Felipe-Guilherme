/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 27
 * Descricao: Declara variaveis de tipos int, double, char e string, le os
 *            valores do usuario e os exibe.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int numeroInteiro;
    double numeroDecimal;
    char caractere;
    char texto[100];

    printf("Digite um numero inteiro: ");
    scanf("%d", &numeroInteiro);
    printf("Digite um numero decimal: ");
    scanf("%lf", &numeroDecimal);
    printf("Digite um caractere: ");
    scanf(" %c", &caractere);
    printf("Digite uma string (sem espacos): ");
    scanf("%s", texto);

    printf("Inteiro: %d\n", numeroInteiro);
    printf("Decimal: %.2lf\n", numeroDecimal);
    printf("Caractere: %c\n", caractere);
    printf("String: %s\n", texto);

    return 0;
}
