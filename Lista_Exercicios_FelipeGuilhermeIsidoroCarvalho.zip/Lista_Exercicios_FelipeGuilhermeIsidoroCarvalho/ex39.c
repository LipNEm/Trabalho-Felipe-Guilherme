/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 39
 * Descricao: Calcula manualmente e verifica com o programa o resultado de
 *            int x = 10 + 5 * 2 / 3 - 1;
 * Data: 24/09/2026
 */
#include <stdio.h>

/*
 * Calculo manual: 10 + 5*2/3 - 1
 * Precedencia: primeiro * e / (esquerda para direita), depois + e -
 * 5*2 = 10; 10/3 = 3 (divisao inteira); 10 + 3 - 1 = 12
 */

int main(void) {
    int x = 10 + 5 * 2 / 3 - 1;
    printf("x = %d\n", x);
    return 0;
}
