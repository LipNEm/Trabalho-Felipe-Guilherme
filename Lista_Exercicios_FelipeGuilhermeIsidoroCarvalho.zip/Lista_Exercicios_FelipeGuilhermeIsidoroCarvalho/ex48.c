/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 48
 * Descricao: Calcula as raizes de uma equacao do segundo grau, tratando
 *            os casos de delta negativo, zero e positivo.
 * Data: 24/09/2026
 */
#include <stdio.h>
#include <math.h>

int main(void) {
    double a, b, c, delta, x1, x2;
    printf("Digite a, b, c: ");
    scanf("%lf %lf %lf", &a, &b, &c);

    delta = b * b - 4 * a * c;

    if (delta < 0) {
        printf("Nao ha raizes reais.\n");
    } else if (delta == 0) {
        x1 = -b / (2 * a);
        printf("Raiz unica: %.2f\n", x1);
    } else {
        x1 = (-b + sqrt(delta)) / (2 * a);
        x2 = (-b - sqrt(delta)) / (2 * a);
        printf("Raizes: %.2f e %.2f\n", x1, x2);
    }

    return 0;
}
