/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 19
 * Descricao: Le dia, mes e ano e verifica se a data e valida, considerando
 *            anos bissextos.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int dia, mes, ano;
    printf("Digite dia mes ano: ");
    scanf("%d %d %d", &dia, &mes, &ano);

    int bissexto = (ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0);
    int diasNoMes[] = {31, bissexto ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    int valido = (mes >= 1 && mes <= 12) && (dia >= 1 && dia <= diasNoMes[mes - 1]);

    if (valido) printf("Data valida!\n");
    else printf("Data invalida!\n");

    return 0;
}
