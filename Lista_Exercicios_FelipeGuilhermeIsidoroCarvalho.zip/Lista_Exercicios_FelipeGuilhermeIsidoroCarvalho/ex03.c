/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 03
 * Descricao: Decomposicao do problema "organizar a biblioteca de uma
 *            empresa" e demonstracao de como a repeticao automatiza a
 *            catalogacao de livros.
 * Data: 24/09/2026
 */
#include <stdio.h>
#define MAX 5

/*
 * Decomposicao do problema "organizar a biblioteca de uma empresa":
 * 1. Cadastrar livros (titulo, autor, categoria, codigo)
 * 2. Ordenar/organizar por categoria ou autor
 * 3. Catalogar (gerar indice/etiquetas)
 * 4. Controlar emprestimo/devolucao
 * 5. Permitir consulta e busca
 *
 * A repeticao (lacos) pode automatizar a catalogacao percorrendo toda a
 * lista de livros e aplicando a mesma acao (gerar etiqueta, ordenar, etc.)
 * a cada um deles, sem precisar repetir o codigo manualmente.
 */

void catalogarLivro(const char *titulo, int codigo) {
    printf("Catalogando livro #%d: %s\n", codigo, titulo);
}

int main(void) {
    const char *livros[MAX] = {"Dom Casmurro", "O Cortico", "Iracema",
                                "Vidas Secas", "Memorias Postumas"};
    for (int i = 0; i < MAX; i++) {
        catalogarLivro(livros[i], i + 1);
    }
    return 0;
}
