/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 53
 * Descricao: Le um ano e verifica se ele e bissexto.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int ano;
    printf("Digite um ano: ");
    scanf("%d", &ano);

    if ((ano % 4 == 0 && ano % 100 != 0) || ano % 400 == 0)
        printf("%d e bissexto\n", ano);
    else
        printf("%d nao e bissexto\n", ano);

    return 0;
}
