/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 05
 * Descricao: Explica como os quatro pilares do pensamento computacional
 *            se aplicam a um sistema de recomendacao de filmes.
 * Data: 24/09/2026
 */
#include <stdio.h>

/*
 * Os quatro pilares do pensamento computacional aplicados a um sistema de
 * recomendacao de filmes:
 *
 * 1. Decomposicao: dividir o problema em partes menores - coletar dados do
 *    usuario, coletar dados dos filmes, calcular similaridade, gerar lista.
 * 2. Reconhecimento de padroes: identificar generos, atores e diretores que
 *    o usuario mais assiste/avalia bem, encontrando padroes de preferencia.
 * 3. Abstracao: ignorar detalhes irrelevantes (ex.: cor da capa do filme) e
 *    focar no que importa (genero, nota, ano, atores).
 * 4. Algoritmos: criar um passo a passo (ex.: filtragem colaborativa) que,
 *    dado o historico do usuario, calcula e ordena os filmes mais
 *    recomendados.
 */

int main(void) {
    printf("Ver comentarios do codigo para a explicacao dos 4 pilares.\n");
    return 0;
}
