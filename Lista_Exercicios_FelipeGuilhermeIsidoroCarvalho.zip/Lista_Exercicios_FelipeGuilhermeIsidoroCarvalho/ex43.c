/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 43
 * Descricao: Le dois numeros e um caractere de operacao, e usa switch-case
 *            para exibir o resultado da operacao.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    float n1, n2, resultado;
    char op;

    printf("Digite o primeiro numero: ");
    scanf("%f", &n1);
    printf("Digite o operador (+ - * /): ");
    scanf(" %c", &op);
    printf("Digite o segundo numero: ");
    scanf("%f", &n2);

    switch (op) {
        case '+': resultado = n1 + n2; break;
        case '-': resultado = n1 - n2; break;
        case '*': resultado = n1 * n2; break;
        case '/':
            if (n2 == 0) {
                printf("Erro: divisao por zero!\n");
                return 1;
            }
            resultado = n1 / n2;
            break;
        default:
            printf("Operador invalido!\n");
            return 1;
    }

    printf("Resultado: %.2f\n", resultado);
    return 0;
}
