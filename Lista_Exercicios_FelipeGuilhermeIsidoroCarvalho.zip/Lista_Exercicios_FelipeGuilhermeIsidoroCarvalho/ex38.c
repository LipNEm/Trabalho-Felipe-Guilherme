/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 38
 * Descricao: Reescreve um bloco if/else de verificacao de maioridade
 *            usando o operador ternario.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int idade;
    printf("Digite a idade: ");
    scanf("%d", &idade);

    printf(idade >= 18 ? "Maior de idade\n" : "Menor de idade\n");

    return 0;
}
