/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 36
 * Descricao: Le e armazena, sem usar structs, os dados de um aluno (nome,
 *            matricula e 3 notas), calculando a media.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    char nome[100];
    int matricula;
    float nota1, nota2, nota3, media;

    printf("Nome do aluno: ");
    fgets(nome, sizeof(nome), stdin);
    printf("Matricula: ");
    scanf("%d", &matricula);
    printf("Notas (3): ");
    scanf("%f %f %f", &nota1, &nota2, &nota3);

    media = (nota1 + nota2 + nota3) / 3;

    printf("Aluno: %s", nome);
    printf("Matricula: %d\n", matricula);
    printf("Media: %.2f\n", media);

    return 0;
}
