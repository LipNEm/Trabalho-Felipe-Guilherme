/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 46
 * Descricao: Le uma temperatura em Fahrenheit e a converte para Celsius.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    float f, c;
    printf("Digite a temperatura em Fahrenheit: ");
    scanf("%f", &f);

    c = (f - 32) * 5.0f / 9.0f;
    printf("Temperatura em Celsius: %.2f\n", c);

    return 0;
}
