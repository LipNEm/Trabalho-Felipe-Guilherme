/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 29
 * Descricao: Demonstra o conceito de escopo com uma variavel local x na
 *            funcao e outra x no main.
 * Data: 24/09/2026
 */
#include <stdio.h>

void funcao(void) {
    int x = 10;
    printf("x dentro da funcao: %d\n", x);
}

int main(void) {
    int x = 5;
    funcao();
    printf("x dentro do main: %d\n", x);

    /*
     * Explicacao: as duas variaveis x sao independentes, pois cada uma tem
     * escopo local (existem apenas dentro do bloco onde foram declaradas).
     * Alterar o x da funcao() nao afeta o x do main().
     */
    return 0;
}
