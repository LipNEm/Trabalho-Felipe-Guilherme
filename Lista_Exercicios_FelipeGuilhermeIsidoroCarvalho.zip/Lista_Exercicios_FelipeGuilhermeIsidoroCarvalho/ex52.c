/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 52
 * Descricao: Le 3 numeros e os imprime em ordem crescente sem usar
 *            arrays, apenas com logica de if.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int a, b, c, menor, meio, maior;
    printf("Digite tres numeros: ");
    scanf("%d %d %d", &a, &b, &c);

    menor = a;
    maior = a;
    if (b < menor) menor = b;
    if (c < menor) menor = c;
    if (b > maior) maior = b;
    if (c > maior) maior = c;
    meio = (a + b + c) - menor - maior;

    printf("Ordem crescente: %d %d %d\n", menor, meio, maior);
    return 0;
}
