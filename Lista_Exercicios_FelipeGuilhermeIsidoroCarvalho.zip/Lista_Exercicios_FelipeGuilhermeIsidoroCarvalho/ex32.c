/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 32
 * Descricao: Le dois numeros e troca seus valores usando a funcao
 *            trocarValores, com passagem por referencia (ponteiros).
 * Data: 24/09/2026
 */
#include <stdio.h>

void trocarValores(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

int main(void) {
    int num1, num2;
    printf("Digite dois numeros: ");
    scanf("%d %d", &num1, &num2);

    printf("Antes: num1=%d, num2=%d\n", num1, num2);
    trocarValores(&num1, &num2);
    printf("Depois: num1=%d, num2=%d\n", num1, num2);

    return 0;
}
