/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 51
 * Descricao: Le o dia da semana usando switch-case, com validacao para
 *            numeros fora do intervalo 1-7.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int dia;
    printf("Digite o dia da semana (1-7): ");
    scanf("%d", &dia);

    if (dia < 1 || dia > 7) {
        printf("Valor invalido! Digite um numero entre 1 e 7.\n");
        return 1;
    }

    switch (dia) {
        case 1: printf("Domingo\n"); break;
        case 2: printf("Segunda-feira\n"); break;
        case 3: printf("Terca-feira\n"); break;
        case 4: printf("Quarta-feira\n"); break;
        case 5: printf("Quinta-feira\n"); break;
        case 6: printf("Sexta-feira\n"); break;
        case 7: printf("Sabado\n"); break;
    }

    return 0;
}
