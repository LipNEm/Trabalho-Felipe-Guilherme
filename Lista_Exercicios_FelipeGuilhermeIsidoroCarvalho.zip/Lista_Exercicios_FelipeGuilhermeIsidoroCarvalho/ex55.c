/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 55
 * Descricao: Exibe um menu de operacoes matematicas e executa a operacao
 *            escolhida usando switch-case.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int opcao;
    float n1, n2;

    printf("1-Soma\n2-Subtracao\n3-Multiplicacao\n4-Divisao\n");
    printf("Escolha uma opcao: ");
    scanf("%d", &opcao);
    printf("Digite dois numeros: ");
    scanf("%f %f", &n1, &n2);

    switch (opcao) {
        case 1: printf("Resultado: %.2f\n", n1 + n2); break;
        case 2: printf("Resultado: %.2f\n", n1 - n2); break;
        case 3: printf("Resultado: %.2f\n", n1 * n2); break;
        case 4:
            if (n2 == 0) printf("Erro: divisao por zero!\n");
            else printf("Resultado: %.2f\n", n1 / n2);
            break;
        default:
            printf("Opcao invalida!\n");
    }

    return 0;
}
