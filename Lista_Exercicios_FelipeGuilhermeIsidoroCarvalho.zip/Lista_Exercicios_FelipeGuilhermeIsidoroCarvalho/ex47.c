/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 47
 * Descricao: Le o salario de um funcionario e calcula o aumento (20%, 10%
 *            ou 5%) de acordo com a faixa salarial.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    float salario, aumento, novoSalario;
    printf("Digite o salario: ");
    scanf("%f", &salario);

    if (salario < 1000) aumento = 0.20f;
    else if (salario <= 2000) aumento = 0.10f;
    else aumento = 0.05f;

    novoSalario = salario + salario * aumento;
    printf("Novo salario: %.2f\n", novoSalario);

    return 0;
}
