/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 24
 * Descricao: Reescreve o programa de verificacao par/impar adicionando
 *            comentarios descritivos para cada bloco logico.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int n;
    /* Le um numero inteiro digitado pelo usuario */
    scanf("%d", &n);

    /* Verifica se o numero e par (resto da divisao por 2 igual a 0) */
    if (n % 2 == 0)
        printf("par"); /* Imprime "par" quando a condicao acima e verdadeira */
    else
        printf("impar"); /* Caso contrario, o numero e impar */

    return 0; /* Encerra o programa com sucesso */
}
