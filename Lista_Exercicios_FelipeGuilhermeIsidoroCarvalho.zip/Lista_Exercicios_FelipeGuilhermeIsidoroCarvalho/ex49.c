/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 49
 * Descricao: Le uma nota de 0 a 100 e converte para conceito (A, B, C, D
 *            ou F), usando if/else if.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    float nota;
    printf("Digite a nota (0-100): ");
    scanf("%f", &nota);

    if (nota >= 90) printf("Conceito: A\n");
    else if (nota >= 80) printf("Conceito: B\n");
    else if (nota >= 70) printf("Conceito: C\n");
    else if (nota >= 60) printf("Conceito: D\n");
    else printf("Conceito: F\n");

    return 0;
}
