/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 08
 * Descricao: Jogo onde o computador pensa em um numero de 1 a 100 e o
 *            usuario tenta adivinhar, recebendo dicas de maior/menor.
 * Data: 24/09/2026
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
    srand((unsigned int) time(NULL));
    int numeroSecreto = rand() % 100 + 1;
    int chute;

    printf("Adivinhe o numero entre 1 e 100:\n");
    do {
        printf("Seu chute: ");
        scanf("%d", &chute);
        if (chute > numeroSecreto) printf("Menor!\n");
        else if (chute < numeroSecreto) printf("Maior!\n");
        else printf("Voce acertou!\n");
    } while (chute != numeroSecreto);

    return 0;
}
