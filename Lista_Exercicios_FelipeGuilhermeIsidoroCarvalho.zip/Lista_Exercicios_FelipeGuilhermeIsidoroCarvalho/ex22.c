/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 22
 * Descricao: Identifica e corrige um erro de sintaxe e um erro semantico
 *            no codigo fornecido.
 * Data: 24/09/2026
 */
#include <stdio.h>

/*
 * Codigo original (com erros):
 *
 * int main()
 * {
 *   printf("O resultado e %d", 10 / 0);
 *   return 0
 * }
 *
 * Erro de sintaxe: falta o ";" apos "return 0".
 * Erro semantico: divisao por zero (comportamento indefinido).
 *
 * Correcao abaixo, usando um divisor diferente de zero.
 */

int main(void) {
    int divisor = 2;
    printf("O resultado e %d\n", 10 / divisor);
    return 0;
}
