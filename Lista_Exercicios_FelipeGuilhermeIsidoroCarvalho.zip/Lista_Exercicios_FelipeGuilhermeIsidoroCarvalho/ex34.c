/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 34
 * Descricao: Declara uma constante PI e a usa para calcular a area de um
 *            circulo.
 * Data: 24/09/2026
 */
#include <stdio.h>

#define PI 3.14159

int main(void) {
    float raio, area;
    printf("Digite o raio: ");
    scanf("%f", &raio);

    area = PI * raio * raio;
    printf("Area do circulo: %.2f\n", area);

    return 0;
}
