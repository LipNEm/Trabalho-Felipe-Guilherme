/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 44
 * Descricao: Explica e mostra o resultado da expressao
 *            (5 > 3) && (2 == 2) || !(10 < 5).
 * Data: 24/09/2026
 */
#include <stdio.h>

/*
 * (5 > 3) && (2 == 2) || !(10 < 5)
 * (5>3)=1, (2==2)=1, 1&&1=1
 * (10<5)=0, !0=1
 * 1 || 1 = 1
 * Resultado impresso: 1
 */

int main(void) {
    printf("%d", (5 > 3) && (2 == 2) || !(10 < 5));
    return 0;
}
