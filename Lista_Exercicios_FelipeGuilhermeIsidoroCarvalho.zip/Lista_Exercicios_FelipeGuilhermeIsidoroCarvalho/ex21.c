/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 21
 * Descricao: Explica a importancia de um debugger na escrita de codigo,
 *            com um exemplo de uso.
 * Data: 24/09/2026
 */
#include <stdio.h>

/*
 * Um debugger permite executar o programa passo a passo, inspecionando o
 * valor das variaveis, a pilha de chamadas e o fluxo de execucao em tempo
 * real, sem precisar adicionar varios printf's no codigo.
 *
 * Exemplo: se um programa trava ou retorna um valor errado, o programador
 * pode colocar um breakpoint na funcao suspeita e observar, linha a linha,
 * em que momento uma variavel recebe um valor incorreto (ex.: um indice de
 * vetor que ultrapassa o limite), facilitando encontrar a causa raiz do
 * erro rapidamente.
 */

int main(void) {
    printf("Ver comentarios do codigo para a explicacao sobre debuggers.\n");
    return 0;
}
