/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 56
 * Descricao: Simula um sistema de login com usuario e senha, concedendo
 *            acesso apenas se ambos estiverem corretos.
 * Data: 24/09/2026
 */
#include <stdio.h>
#include <string.h>

int main(void) {
    char usuario[50], senha[50];
    printf("Usuario: ");
    scanf("%49s", usuario);
    printf("Senha: ");
    scanf("%49s", senha);

    if (strcmp(usuario, "admin") == 0 && strcmp(senha, "1234") == 0)
        printf("Acesso concedido!\n");
    else
        printf("Acesso negado!\n");

    return 0;
}
