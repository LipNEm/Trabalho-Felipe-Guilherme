/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 18
 * Descricao: Le um numero e verifica, com uma unica expressao logica, se
 *            ele esta no intervalo [10, 20].
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int n;
    printf("Digite um numero: ");
    scanf("%d", &n);

    printf("Esta no intervalo [10,20]? %s\n", (n >= 10 && n <= 20) ? "Sim" : "Nao");

    return 0;
}
