/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 28
 * Descricao: Le o raio de um circulo e calcula sua area e perimetro,
 *            usando a constante M_PI.
 * Data: 24/09/2026
 */
#include <stdio.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

int main(void) {
    float raio;
    printf("Digite o raio do circulo: ");
    scanf("%f", &raio);

    float area = M_PI * raio * raio;
    float perimetro = 2 * M_PI * raio;

    printf("Area: %.2f\n", area);
    printf("Perimetro: %.2f\n", perimetro);

    return 0;
}
