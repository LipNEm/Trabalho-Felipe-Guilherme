/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 02
 * Descricao: Le um numero N e imprime os primeiros N termos da sequencia
 *            de Fibonacci, explicando o padrao de repeticao.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int n;
    printf("Digite o valor de N: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("N deve ser positivo.\n");
        return 0;
    }

    long long a = 0, b = 1, prox;
    printf("Primeiros %d termos da sequencia de Fibonacci:\n", n);
    for (int i = 0; i < n; i++) {
        printf("%lld ", a);
        prox = a + b;
        a = b;
        b = prox;
    }
    printf("\n");
    printf("Padrao: cada termo eh a soma dos dois anteriores (Fn = Fn-1 + Fn-2).\n");
    return 0;
}
