/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 12
 * Descricao: Calcula o IMC (peso / altura ao quadrado) e classifica o
 *            resultado.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    float peso, altura, imc;
    printf("Digite o peso (kg): ");
    scanf("%f", &peso);
    printf("Digite a altura (m): ");
    scanf("%f", &altura);

    imc = peso / (altura * altura);
    printf("IMC: %.2f\n", imc);

    if (imc < 18.5) printf("Classificacao: Abaixo do peso\n");
    else if (imc < 25) printf("Classificacao: Peso normal\n");
    else if (imc < 30) printf("Classificacao: Sobrepeso\n");
    else printf("Classificacao: Obesidade\n");

    return 0;
}
