/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 16
 * Descricao: Le a nota e a frequencia de um aluno e verifica aprovacao
 *            usando logica proposicional no if.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    float nota, frequencia;
    printf("Digite a nota: ");
    scanf("%f", &nota);
    printf("Digite a frequencia (%%): ");
    scanf("%f", &frequencia);

    if (nota >= 7 && frequencia >= 75) printf("Aprovado\n");
    else printf("Reprovado\n");

    return 0;
}
