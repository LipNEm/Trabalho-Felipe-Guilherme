/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 01
 * Descricao: Algoritmo (pseudocodigo em comentarios) para lavar um carro,
 *            com identificacao de 3 sub-rotinas que podem virar funcoes.
 * Data: 24/09/2026
 */
#include <stdio.h>

/*
 * Pseudocodigo - Lavar um carro:
 * 1. Molhar o carro inteiro com agua
 * 2. Aplicar sabao/shampoo automotivo com uma esponja
 * 3. Esfregar a carroceria, rodas e vidros
 * 4. Enxaguar todo o sabao com agua
 * 5. Secar o carro com um pano de microfibra
 *
 * Tres partes que podem ser abstraidas em sub-rotinas (funcoes):
 * - molharCarro()
 * - ensaboarCarro()
 * - secarCarro()
 */

void molharCarro(void) {
    printf("Molhando o carro...\n");
}

void ensaboarCarro(void) {
    printf("Aplicando sabao e esfregando o carro...\n");
}

void secarCarro(void) {
    printf("Secando o carro com pano de microfibra...\n");
}

int main(void) {
    printf("Iniciando processo de lavagem do carro:\n");
    molharCarro();
    ensaboarCarro();
    printf("Enxaguando o carro...\n");
    secarCarro();
    printf("Carro lavado com sucesso!\n");
    return 0;
}
