/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 25
 * Descricao: Explica o que o programa faz e qual a saida quando o usuario
 *            digita 10 (calcula o dobro de um numero).
 * Data: 24/09/2026
 */
#include <stdio.h>

/*
 * O programa le um numero inteiro e imprime o dobro dele.
 * Se o usuario digitar 10, a saida sera: "O dobro de 10 eh 20"
 */

int main(void) {
    int x, y;
    printf("Digite um numero: ");
    scanf("%d", &x);
    y = x * 2;
    printf("O dobro de %d eh %d", x, y);
    return 0;
}
