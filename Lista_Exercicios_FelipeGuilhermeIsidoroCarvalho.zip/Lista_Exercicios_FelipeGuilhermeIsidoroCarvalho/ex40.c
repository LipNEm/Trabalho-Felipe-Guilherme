/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 40
 * Descricao: Le um numero e usa operadores bit a bit para dobra-lo (shift
 *            left) e dividi-lo por 2 (shift right).
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int n;
    printf("Digite um numero: ");
    scanf("%d", &n);

    printf("Dobro (shift left): %d\n", n << 1);
    printf("Metade (shift right): %d\n", n >> 1);

    return 0;
}
