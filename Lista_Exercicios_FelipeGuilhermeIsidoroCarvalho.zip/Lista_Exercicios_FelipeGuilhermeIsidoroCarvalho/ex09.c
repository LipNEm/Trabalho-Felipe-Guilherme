/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 09
 * Descricao: Desenha um quadrado de asteriscos no console, abstraido na
 *            funcao desenhaQuadrado(int lado).
 * Data: 24/09/2026
 */
#include <stdio.h>

void desenhaQuadrado(int lado) {
    for (int i = 0; i < lado; i++) {
        for (int j = 0; j < lado; j++) printf("*");
        printf("\n");
    }
}

int main(void) {
    desenhaQuadrado(5);
    return 0;
}
