/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 10
 * Descricao: Calcula o menor numero de moedas (1, 5, 10, 25 centavos) para
 *            dar troco, usando estrategia gulosa.
 * Data: 24/09/2026
 */
#include <stdio.h>

/*
 * Decomposicao: o problema de dar troco eh dividido em escolher, a cada
 * passo, a maior moeda possivel que "cabe" no valor restante.
 * Estrategia gulosa (greedy): sempre usar a maior moeda disponivel primeiro,
 * repetindo ate o troco chegar a zero.
 */

int main(void) {
    int moedas[] = {25, 10, 5, 1};
    int troco, qtd = 0;

    printf("Digite o valor do troco (em centavos): ");
    scanf("%d", &troco);

    for (int i = 0; i < 4; i++) {
        int n = troco / moedas[i];
        if (n > 0) {
            printf("%d moeda(s) de %d centavos\n", n, moedas[i]);
            qtd += n;
            troco -= n * moedas[i];
        }
    }
    printf("Total de moedas usadas: %d\n", qtd);
    return 0;
}
