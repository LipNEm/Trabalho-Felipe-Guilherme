/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 50
 * Descricao: Le peso e altura, calcula o IMC e exibe a classificacao
 *            usando uma estrutura de decisao encadeada.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    float peso, altura, imc;
    printf("Digite o peso (kg): ");
    scanf("%f", &peso);
    printf("Digite a altura (m): ");
    scanf("%f", &altura);

    imc = peso / (altura * altura);
    printf("IMC: %.2f\n", imc);

    if (imc < 18.5) printf("Abaixo do peso\n");
    else if (imc < 25) printf("Peso normal\n");
    else if (imc < 30) printf("Sobrepeso\n");
    else if (imc < 40) printf("Obesidade\n");
    else printf("Obesidade grave\n");

    return 0;
}
