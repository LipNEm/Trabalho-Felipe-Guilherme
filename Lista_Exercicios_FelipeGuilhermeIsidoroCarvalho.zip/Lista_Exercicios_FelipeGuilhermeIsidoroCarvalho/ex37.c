/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 37
 * Descricao: Le a, b e c e calcula x na formula de Bhaskara parcial
 *            x = (-b + sqrt(b^2 - 4ac)) / (2a).
 * Data: 24/09/2026
 */
#include <stdio.h>
#include <math.h>

int main(void) {
    double a, b, c, delta, x;
    printf("Digite a, b, c: ");
    scanf("%lf %lf %lf", &a, &b, &c);

    delta = b * b - 4 * a * c;
    if (delta < 0) {
        printf("Nao existe raiz real (delta negativo).\n");
        return 0;
    }

    x = (-b + sqrt(delta)) / (2 * a);
    printf("x = %.2f\n", x);

    return 0;
}
