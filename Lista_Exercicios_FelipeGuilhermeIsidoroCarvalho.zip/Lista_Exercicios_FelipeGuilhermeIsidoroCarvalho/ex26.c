/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 26
 * Descricao: Explica a importancia de nomes significativos para variaveis
 *            e funcoes, com exemplo de codigo ruim reescrito.
 * Data: 24/09/2026
 */
#include <stdio.h>

/*
 * Nomes significativos deixam o codigo mais legivel e facil de manter,
 * pois qualquer pessoa entende o proposito da variavel/funcao sem precisar
 * ler todo o contexto ao redor.
 *
 * Exemplo com nomes ruins:
 * int a, b, c;
 * a = 10; b = 5;
 * c = a * b;
 * printf("%d", c);
 *
 * Reescrito com nomes melhores abaixo.
 */

int main(void) {
    int quantidade = 10;
    int precoUnitario = 5;
    int totalCompra = quantidade * precoUnitario;
    printf("Total da compra: %d\n", totalCompra);
    return 0;
}
