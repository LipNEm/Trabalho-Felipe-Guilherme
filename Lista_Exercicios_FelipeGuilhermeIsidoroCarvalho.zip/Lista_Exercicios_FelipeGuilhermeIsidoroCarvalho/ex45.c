/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 45
 * Descricao: Dado a=5 e b=10, calcula c = a++ + --b e mostra os valores
 *            finais de a, b e c.
 * Data: 24/09/2026
 */
#include <stdio.h>

/*
 * a=5, b=10
 * c = a++ + --b;
 * a++ usa 5 e depois a vira 6
 * --b decrementa antes: b vira 9, usa 9
 * c = 5 + 9 = 14
 * Valores finais: a=6, b=9, c=14
 */

int main(void) {
    int a = 5, b = 10;
    int c = a++ + --b;
    printf("a=%d, b=%d, c=%d\n", a, b, c);
    return 0;
}
