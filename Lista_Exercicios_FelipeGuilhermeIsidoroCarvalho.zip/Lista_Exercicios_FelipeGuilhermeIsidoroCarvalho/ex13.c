/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 13
 * Descricao: Le tres numeros e verifica se estao em ordem crescente ou
 *            decrescente, usando operadores logicos.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    float a, b, c;
    printf("Digite tres numeros: ");
    scanf("%f %f %f", &a, &b, &c);

    if (a < b && b < c) printf("Ordem crescente\n");
    else if (a > b && b > c) printf("Ordem decrescente\n");
    else printf("Nao estao em ordem crescente nem decrescente\n");

    return 0;
}
