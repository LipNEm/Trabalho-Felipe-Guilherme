/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 14
 * Descricao: Dadas duas variaveis booleanas A e B, calcula e exibe os
 *            resultados de A && B, A || B, !A e A ^ B.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int A, B;
    printf("Digite A e B (0 ou 1): ");
    scanf("%d %d", &A, &B);

    printf("A && B = %d\n", A && B);
    printf("A || B = %d\n", A || B);
    printf("!A = %d\n", !A);
    printf("A ^ B = %d\n", A ^ B);

    return 0;
}
