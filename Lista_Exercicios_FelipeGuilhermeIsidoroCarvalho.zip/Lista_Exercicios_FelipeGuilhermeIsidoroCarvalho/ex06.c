/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 06
 * Descricao: Reescreve a soma de 1 a N usando while e formula matematica,
 *            comparando a eficiencia das abordagens.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int n, somaFor = 0, somaWhile = 0, somaFormula;
    printf("Digite N: ");
    scanf("%d", &n);

    for (int i = 1; i <= n; i++) somaFor += i;

    int i = 1;
    while (i <= n) {
        somaWhile += i;
        i++;
    }

    somaFormula = n * (n + 1) / 2;

    printf("Soma (for): %d\n", somaFor);
    printf("Soma (while): %d\n", somaWhile);
    printf("Soma (formula): %d\n", somaFormula);
    printf("A formula matematica e mais eficiente: complexidade O(1),\n");
    printf("enquanto os lacos for/while tem complexidade O(n).\n");
    return 0;
}
