/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 11
 * Descricao: Le um valor em reais e uma taxa de cambio e converte para
 *            dolares.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    float reais, taxa, dolares;
    printf("Digite o valor em reais: ");
    scanf("%f", &reais);
    printf("Digite a taxa de cambio (R$ por US$): ");
    scanf("%f", &taxa);

    dolares = reais / taxa;
    printf("Valor em dolares: %.2f\n", dolares);
    return 0;
}
