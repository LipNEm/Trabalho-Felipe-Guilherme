/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 41
 * Descricao: Le um caractere e verifica se ele e uma letra minuscula,
 *            usando operadores logicos e relacionais.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    char c;
    printf("Digite um caractere: ");
    scanf(" %c", &c);

    if (c >= 'a' && c <= 'z') printf("%c e uma letra minuscula\n", c);
    else printf("%c nao e uma letra minuscula\n", c);

    return 0;
}
