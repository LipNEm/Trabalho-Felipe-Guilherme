/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 33
 * Descricao: Le 4 notas, calcula a media e exibe o resultado com duas
 *            casas decimais.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    float n1, n2, n3, n4, media;
    printf("Digite 4 notas: ");
    scanf("%f %f %f %f", &n1, &n2, &n3, &n4);

    media = (n1 + n2 + n3 + n4) / 4;
    printf("Media: %.2f\n", media);

    return 0;
}
