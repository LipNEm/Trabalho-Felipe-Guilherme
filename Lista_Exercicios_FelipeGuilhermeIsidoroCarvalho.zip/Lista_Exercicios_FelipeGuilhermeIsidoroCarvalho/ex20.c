/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 20
 * Descricao: Descreve o processo do arquivo .c ate a execucao do programa
 *            (compilador, linker, codigo objeto e executavel).
 * Data: 24/09/2026
 */
#include <stdio.h>

/*
 * Do arquivo .c ate a execucao:
 * 1. Codigo-fonte (.c): escrito pelo programador em C.
 * 2. Pre-processador: expande includes, macros e defines, gerando um
 *    codigo-fonte "puro" (traducao de #include, #define, etc.).
 * 3. Compilador: traduz o codigo-fonte em codigo assembly e depois em
 *    codigo objeto (.o), especifico da arquitetura da maquina.
 * 4. Linker (ligador): junta o codigo objeto do programa com as bibliotecas
 *    necessarias (ex.: stdio), resolvendo referencias a funcoes externas,
 *    gerando o arquivo executavel final.
 * 5. Executavel: arquivo binario que o sistema operacional carrega na
 *    memoria e executa.
 */

int main(void) {
    printf("Ver comentarios do codigo para a explicacao do processo.\n");
    return 0;
}
