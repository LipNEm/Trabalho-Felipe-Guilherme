/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 23
 * Descricao: Explica e mostra a saida do programa com pre e pos
 *            incremento (a++, ++a).
 * Data: 24/09/2026
 */
#include <stdio.h>

/*
 * Saida esperada:
 * 5   -> imprime a antes de qualquer alteracao
 * 5   -> a++ imprime o valor atual (5) e DEPOIS incrementa (a vira 6)
 * 7   -> ++a incrementa ANTES (a vira 7) e imprime o novo valor
 */

int main(void) {
    int a = 5;
    printf("%d\n", a);
    printf("%d\n", a++);
    printf("%d\n", ++a);
    return 0;
}
