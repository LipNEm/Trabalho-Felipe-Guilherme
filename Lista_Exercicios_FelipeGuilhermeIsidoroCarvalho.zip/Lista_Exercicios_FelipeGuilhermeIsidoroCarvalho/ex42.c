/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 42
 * Descricao: Le os 9 primeiros digitos de um CPF e calcula o primeiro
 *            digito verificador.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int cpf[9];
    int soma = 0;

    printf("Digite os 9 primeiros digitos do CPF (um a um): ");
    for (int i = 0; i < 9; i++) scanf("%d", &cpf[i]);

    for (int i = 0; i < 9; i++) soma += cpf[i] * (10 - i);

    int resto = soma % 11;
    int digito = (resto < 2) ? 0 : 11 - resto;

    printf("Primeiro digito verificador: %d\n", digito);
    return 0;
}
