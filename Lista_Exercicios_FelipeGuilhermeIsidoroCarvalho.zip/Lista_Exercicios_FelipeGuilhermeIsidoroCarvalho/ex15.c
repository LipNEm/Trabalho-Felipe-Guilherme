/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 15
 * Descricao: Le um numero e determina se ele e par ou impar, validando se
 *            a entrada e um numero inteiro.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int n;
    printf("Digite um numero inteiro: ");
    if (scanf("%d", &n) != 1) {
        printf("Entrada invalida! Digite um numero inteiro.\n");
        return 1;
    }

    if (n % 2 == 0) printf("%d e par\n", n);
    else printf("%d e impar\n", n);

    return 0;
}
