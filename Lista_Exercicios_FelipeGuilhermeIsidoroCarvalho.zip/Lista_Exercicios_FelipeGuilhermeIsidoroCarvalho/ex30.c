/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 30
 * Descricao: Le dois numeros inteiros e calcula a divisao real entre eles,
 *            usando cast para float.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    int a, b;
    printf("Digite dois numeros inteiros: ");
    scanf("%d %d", &a, &b);

    float divisao = (float) a / (float) b;
    printf("Divisao real: %.2f\n", divisao);

    return 0;
}
