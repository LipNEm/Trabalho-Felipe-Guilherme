/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 17
 * Descricao: Calcula o salario liquido de um funcionario, aplicando
 *            desconto de 10% de INSS sobre o salario bruto.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    float salarioBruto, inss, salarioLiquido;
    printf("Digite o salario bruto: ");
    scanf("%f", &salarioBruto);

    inss = salarioBruto * 0.10f;
    salarioLiquido = salarioBruto - inss;

    printf("Desconto INSS: %.2f\n", inss);
    printf("Salario liquido: %.2f\n", salarioLiquido);

    return 0;
}
