/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 35
 * Descricao: Exibe o tamanho em bytes dos tipos int, float, double, char
 *            e de um ponteiro para int, usando sizeof.
 * Data: 24/09/2026
 */
#include <stdio.h>

int main(void) {
    printf("Tamanho int: %zu bytes\n", sizeof(int));
    printf("Tamanho float: %zu bytes\n", sizeof(float));
    printf("Tamanho double: %zu bytes\n", sizeof(double));
    printf("Tamanho char: %zu bytes\n", sizeof(char));
    printf("Tamanho ponteiro para int: %zu bytes\n", sizeof(int *));

    return 0;
}
