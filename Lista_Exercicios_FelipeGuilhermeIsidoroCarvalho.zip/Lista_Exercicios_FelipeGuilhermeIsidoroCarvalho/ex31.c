/*
 * Aluno: Felipe Guilherme Isidoro Carvalho
 * Exercicio: 31
 * Descricao: Le o nome completo do usuario com fgets e imprime uma
 *            saudacao personalizada.
 * Data: 24/09/2026
 */
#include <stdio.h>
#include <string.h>

int main(void) {
    char nome[100];
    printf("Digite seu nome completo: ");
    fgets(nome, sizeof(nome), stdin);
    nome[strcspn(nome, "\n")] = '\0';

    printf("Ola, %s! Seja bem-vindo(a).\n", nome);
    return 0;
}
